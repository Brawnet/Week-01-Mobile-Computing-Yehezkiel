//
//  Week_2__18___09___2025_App.swift
//  Week 2 (18 - 09 - 2025)
//
//  Created by student on 18/09/25.
//

import SwiftUI

@main
struct Week_2__18___09___2025_App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
