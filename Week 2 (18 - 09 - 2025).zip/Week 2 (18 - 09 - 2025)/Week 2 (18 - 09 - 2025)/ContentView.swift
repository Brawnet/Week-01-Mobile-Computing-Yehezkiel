//
//  ContentView.swift
//  Week 2 (18 - 09 - 2025)
//
//  Created by student on 18/09/25.
//

import SwiftUI

struct ContentView: View {
//    @State private var isOn: Bool = false
//    @State private var volume: Double = 10
//    @State private var name: String = "Naruto"
//@State private var point = 80
//    private func actionButton(_ title: String, action: @escaping () -> Void) -> some View
//    {
//        Button (title, action: action)
//            .padding(.horizontal, 16) . padding(.vertical, 10)
//            .foregroundColor(.white)
//            .background(Color.blue)
//            .cornerRadius(10)
//    }
//    
//    private func progressCard(score: Int) -> some View {
//        VStack() {
//            Text("Current Score") .font(.headline)
//            Text("\(score)/100")
//                .foregroundStyle(.secondary)
//        }
//    }
//
    
    let fruits = ["Apple", "Orange", "Banana"]
    var body: some View {
//
        let number = 1
        List(fruits, id: \.self){
            fruit in HStack{
                Text(fruit)
                Spacer()
                Text("\(number)")
            }
        }
//        VStack{
//            Text("\(point)")
//            HStack{
//                actionButton("Add 10") { point += 10}
//                actionButton("Reset") { point = 0}
//            }
//        }

        
        
        
        
        
        
        
        
        
        
        
        
        
//        VStack
//        {
//            Toggle("Enable Notification", isOn: $isOn)
//            Text(isOn ? "Hore" : "Yahh") //on off button
//            
//            Slider(value: $volume, in: 0...1)
//            Text("Volume Sekarang : \(volume)%") //slider volume
//            
//            TextField("Namamu Siapa?", text: $name)
//                .textFieldStyle(.roundedBorder)
//                .padding() //isi teks
//        }
        
        
        
        //            HStack
        //            {
        //
        //                Text("Yehezkiel")
        //                    .padding(.top , -80)
        //                    .foregroundStyle(.black)
        //                    .background(Color.white)
        //                Spacer()
        //                VStack
        //                {
        //                    Text("🙈")
        //                    Text("🥕😊")
        //                }
        //                .padding(.top , 120)
        //            }
        //            .frame(width: 199, height: 199)
        //            .background(Color.white)
        //            .overlay(
        //                RoundedRectangle(cornerRadius: 10)
        //                .stroke(Color.black, lineWidth: 2)
        //                    )
        //            .cornerRadius(10)
        //            .shadow(color: .black, radius: 5, x:2, y:2)
        
        
        
        
        
        
        
        
        
        //        VStack
        //        {
        //            Spacer()
        //            Image(systemName: "bitcoinsign")
        //                .font(.system(size: 50))
        //            Spacer()
        //            Button("Free Bitcoin")
        //            {
        //                print("1 bitcoin di tambahkan ke dompet anda")
        //            }
        //            .foregroundStyle(.white)
        //            .frame(width: 100, height: 50)
        //            .background(Color.blue)
        //            .overlay(
        //            RoundedRectangle(cornerRadius: 10)
        //            .stroke(Color.black, lineWidth: 2)
        //            )
        //            .cornerRadius(10)
        //            .shadow(color: .black, radius: 1, x:1, y:1)
        //
        //
        //        }
        
        
        
    }}

#Preview {
    ContentView()
}
