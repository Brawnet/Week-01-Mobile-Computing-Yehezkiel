//
//  Week_2__18___09___2025_Tests.swift
//  Week 2 (18 - 09 - 2025)Tests
//
//  Created by student on 18/09/25.
//

import Testing
@testable import Week_2__18___09___2025_

struct Week_2__18___09___2025_Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
